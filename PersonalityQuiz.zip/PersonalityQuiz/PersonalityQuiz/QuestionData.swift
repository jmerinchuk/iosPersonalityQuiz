/*******************************************************
 * Program: Personality Quiz
 * Programmer: Jayce Merinchuk
 * Guided By: App Development with Swift iOs 12
 * Date: Wednesday August 14, 2019
 * Description: Basic Personality quiz created with
 * assistance from the App Development with Swift
 * iOs 12 Edition book.
 ******************************************************/

// Imports
import Foundation

/******************************************************
 * Struct: Question
 * Description: Has text, a type, and answers
 *****************************************************/
struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}

/*****************************************************
 * Enum: ResponseType
 * Description: Type of question presented to user.
 ****************************************************/
enum ResponseType {
    case single, multiple, ranged
}

/****************************************************
 * Struct: Answer
 * Description: Has text and an animal type.
 ***************************************************/
struct Answer {
    var text: String
    var type: AnimalType
}

/***************************************************
 * Enum: AnimalType
 * Description: Picture for animal and personality
 * definition for results screen.
 **************************************************/
enum AnimalType: Character {
    case dog = "🐶", cat = "🐱", rabbit = "🐰", turtle = "🐢"
    
    var definition: String {
        switch self {
        case .dog:
            return "You are incredibly outgoing. You surround yourself with the people you love and enjoy activities with your friends."
        case .cat:
            return "Mischievous, yet mild-tempered, you enjoy doing things on your own terms."
        case .rabbit:
            return "You love everything that's soft. You are healthy and full of energy."
        case .turtle:
            return "You are wise beyond your years, and you focus on the details. Slow and steady wins the race."
        }
    }
}
