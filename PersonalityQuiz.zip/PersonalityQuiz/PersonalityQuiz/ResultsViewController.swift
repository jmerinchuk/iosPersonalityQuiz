/*******************************************************
 * Program: Personality Quiz
 * Programmer: Jayce Merinchuk
 * Guided By: App Development with Swift iOs 12
 * Date: Wednesday August 14, 2019
 * Description: Basic Personality quiz created with
 * assistance from the App Development with Swift
 * iOs 12 Edition book.
 ******************************************************/

import UIKit

class ResultsViewController: UIViewController {

    // Outlets
    @IBOutlet weak var resultAnswerLabel: UILabel!
    @IBOutlet weak var resultDefinitionLabel: UILabel!
    @IBOutlet weak var congratsLabel: UILabel!
    
    // Global Variables
    var responses: [Answer]!
    
    /*************************************************
     * Method: viewDidLoad()
     * Description: Initial screen loaded function.
     *************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        calculatePersonalityResult()
    }
    
    /*************************************************
     * Method: calculatePersonalityResult()
     * Description: adds up all responses based on
     * animal type, sorts, and presents the top number.
     *************************************************/
    func calculatePersonalityResult() {
        var frequencyOfAnswers: [AnimalType: Int] = [:]
        let responseTypes = responses.map { $0.type }
        
        // Tally up answers into Array
        for response in responseTypes {
            let newCount: Int
            
            if let oldCount = frequencyOfAnswers[response] {
                newCount = oldCount + 1
            } else {
                newCount = 1
            }
            
            frequencyOfAnswers[response] = newCount
        }
        
        let mostCommonAnswer = frequencyOfAnswers.sorted{ $0.1 > $1.1}.first!.key
        
        congratsLabel.text = "Congrats!"
        resultAnswerLabel.text = "You are a \(mostCommonAnswer.rawValue)!"
        resultDefinitionLabel.text = mostCommonAnswer.definition
    }
}
