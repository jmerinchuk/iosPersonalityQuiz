/*******************************************************
 * Program: Personality Quiz
 * Programmer: Jayce Merinchuk
 * Guided By: App Development with Swift iOs 12
 * Date: Wednesday August 14, 2019
 * Description: Basic Personality quiz created with
 * assistance from the App Development with Swift
 * iOs 12 Edition book.
 ******************************************************/

// Imports
import UIKit

/******************************************************
 * Class: IntroductionViewController
 * Description: Initial Class Loaded for Intro Screen.
 *****************************************************/
class IntroductionViewController: UIViewController {
    
    /*************************************************
     * Method: viewDidLoad()
     * Description: Initial function loaded.
     ************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    /*************************************************
     * Method: unwindToQuizIntroduction
     * Description: unwinds from results to main screen.
     ************************************************/
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
    }
}
